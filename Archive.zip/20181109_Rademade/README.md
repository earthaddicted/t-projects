Steps to launch the project:

in command line cd to folder with this project
	1)	type npm i
	2)	gulp
